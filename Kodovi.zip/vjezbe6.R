#Simulacija niza reziduala (eps) iz GARCH (1,1) modela
a0 = 0.2
a1 = 0.5
b1= 0.3
n=1000
z = rnorm(n)
eps = numeric(n)
sigsq = numeric(n)
sigsq[1]=ao/(1-a1-b1)
for (i in 2:n) {
  sigsq[i] = a0 + a1 * (eps[i-1]^2) + b1 * sigsq[i-1]
  eps[i] =sqrt(sigsq[i])*z[i]
}
plot(eps, type='l')


#Procjena GARCH parametara koristenjem tseries paketa
install.packages("tseries")
library("tseries") 
eps.garch=garch(eps, trace=FALSE) #default je GARCH(1,1)

eps.garch2 = garch(eps, order=c(2,2),trace=FALSE) 
names(eps.garch)
names(summary(eps.garch))

#usporedba dva GARCH modela koristenjem (negativne) vrijednosti likelihood funkcije
eps.garch$n.likeli

eps.garch2$n.likeli

#Alternativni (napredniji) paket: rugarch, naredba ugarchfit

#Procjena VaR-a za model S(t)=S(t-1)exp(X(t)), gdje je X(t)=mu+eps, eps~GARCH(1,1)
S=GARCH.Price$Price
n=length(S)
r=log(S[2:n])-log(S[1:(n-1)])
mi=mean(r)
eps=r-mi
model=garch(eps, trace=FALSE)

A0=model$coef[1]
A1=model$coef[2]
B1=model$coef[3]
sigest = rep(0, n)
sigest[1]=sqrt(A0/(1-A1-B1))
for (i in 2:n) {
  sigest[i] = sqrt(A0 + A1 * (eps[i-1]^2) + B1 * (sigest[i-1]^2))
}
alpha=0.01 #zadajemo alpha za VaR(alpha)
S_var=numeric(n)
S_var[1]=S[1]
for (i in 2:n){
  S_var[i]=S[i-1]*exp(mi+sigest[i]*qnorm(alpha))
}

#Vizualna usporedba, zelena linija bi trebala biti iznad crvene u (1-alpha)*100% slucajeva
plot(S, type="l", col="green", xlab="Vrijeme")
lines(S_var,col="red")

VaR=S-S_var #Var(t)=iznos za koji smo (1-alpha)*100% sigurni da najvise toliko mozemo izgubiti u trenutku t
