
podaci=read.table("coint.data", header=FALSE)

x=podaci$V1
n=length(x)

#Implementacija Dickey-Fuller testa za AR(1) niz, tip 2 (sa driftom, bez vremenskog trenda)
dx=diff(x)
model=lm(dx~x[1:(n-1)])
phi=summary(model)$coefficients[2,1]
std_err=summary(model)$coefficients[2,2]
tstat=phi/std_err #testna statistika, usporedjujemo s DF tablicom


#DF test za deltaX
dx1=diff(dx)
n1=length(dx)

model1<-lm(dx1~dx[1:(n1-1)])
phi1=summary(model1)$coefficients[2,1]
std_err1=summary(model1)$coefficients[2,2]
tstat1=phi1/std_err1

#Drugi stupac
y=podaci$V2
n=length(y)
dy=diff(y)
model=lm(dy~y[1:(n-1)])

phi=summary(model)$coefficients[2,1]
std_err=summary(model)$coefficients[2,2]
tstat=phi/std_err


dy1=diff(dy)
n1=length(dy)

model1<-lm(dy1~dy[1:(n1-1)])
phi1=summary(model1)$coefficients[2,1]
std_err1=summary(model1)$coefficients[2,2]
tstat1=phi1/std_err1


#Engle-Granger metoda testiranja kointegracije
model2=lm(y~x)
u=model2$residuals
n=length(u)
du=diff(u)
umodel=lm(du~u[1:(n-1)])

phi=summary(umodel)$coefficients[2,1]
std_err=summary(umodel)$coefficients[2,2]
tstat=phi/std_err


#Error Correction Model (kada ima kointegracije)
model=lm(dy1~dx1+u1[2:nu1])
