#Simuliranje ARMA(1,1) modela
c=1
alpha=0.5
beta=1.01
n=10000
x=numeric(n)
x[1]=1
eps=rnorm(n)
for (i in 2:n){
x[i]=c+alpha*x[i-1]+beta*eps[i-1]+eps[i]
}
plot(x,type="l", col="blue")
model=arima(x,order=c(1,0,1)) #procjena parametara ARMA(1,1) modela

#Izracun Treynor omjera, Sharpe omjera i Jensenove alphe
table=read.csv("AAPL.csv", header=TRUE, sep=',') #ucitavanje cijena dionica Applea za odabrani period (asset)
names(table)
cijene=table$Close
n=length(cijene)
povrati_a=(cijene[2:n]-cijene[1:(n-1)])/cijene[1:(n-1)]

plot(povrati_a,type="l", col="blue")

table=read.csv("^GSPC.csv", header=TRUE, sep=',') #ucitavanje vrijednosti S&P indeksa za odabrani period (benchmark)
names(table)
cijene=table$Close
n=length(cijene)
povrati_sp=(cijene[2:n]-cijene[1:(n-1)])/cijene[1:(n-1)]

plot(povrati_sp,type="l", col="red")


rf=0.02/52
y=povrati_a-rf
x=povrati_sp-rf
model=lm(y~x)
beta=model$coefficients[2] #beta imovine (asseta)

sharpe=mean(y)/sd(y) 
treynor=mean(y)/beta
jensen=model$coefficients[1]