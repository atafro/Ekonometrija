
table=read.csv("FB.csv", header=TRUE, sep=',') #ucitavanje podataka
names(table)
cijene=table$Close
plot(cijene, type='l', col="blue")
n=length(cijene)
log_povrati=log(cijene[2:n])-log(cijene[1:(n-1)])

#Vizualizacija podataka
plot(log_povrati, type='l', col="red")
hist(log_povrati)
acf(log_povrati) #graficki prikaz autokorelacijske funkcije

#Testiranje normalnosti
qqnorm(log_povrati)
ks.test(log_povrati, "pnorm")
shapiro.test(log_povrati)

rm(x) #brisanje varijabli

#Simuliranje jednog AR(1) niza
a=0.5
b=1.01
n=1000
x=numeric(n)
x[1]=1
for (i in 2:n){
x[i]=a+b*x[i-1]+rnorm(1);
}