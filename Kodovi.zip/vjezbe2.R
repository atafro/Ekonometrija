podaci=read.csv("podaci_AR.csv", dec=',', header=FALSE)

#Neke korisne naredbe za kontrolu podataka
dim(podaci)
typeof(podaci)
names(podaci)

x=podaci$V1
typeof(x)
plot(x, type="l")

n=length(x)
#AR(1) model uz naredbu lm
model1=lm(x[2:n]~x[1:(n-1)])
names(model1)
beta1=model1$coefficients[2]

#AR(1) bez slobodnog clana
model2=lm(x[2:n]~0+x[1:(n-1)])
beta2=model2$coefficients[1]

#AR(1) model uz naredbu ar
model3=ar(x, aic=FALSE, order.max=1)
beta=model3$ar
m=mean(x)
alpha=m*(1-beta)

#najbolji AR model prema AIC kriteriju
model=ar(x) 

#AR(1) model uz naredbu arima
model4=arima(x, order=c(1,0,0))

#izracun AIC iz naredbe lm
AIC1=2*2-2*logLik(model1)