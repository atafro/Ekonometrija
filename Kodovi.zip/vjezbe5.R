#DF test pomocu paketa urca

install.packages("urca")
library("urca")

podaci=read.table("coint.data", header=FALSE)
x=coint$V1
y=coint$V2

dftest=ur.df(x, type="drift", lags=0, selectlags = "Fixed") #DF test u paketu urca, usp. s prethodnim vjezbama
summary(dftest)
dx=diff(x)
dftest1=ur.df(dx, type="drift", lags=0, selectlags = "Fixed")
summary(dftest1)

dftest=ur.df(y, type="drift", lags=0, selectlags = "Fixed")
summary(dftest)
dy=diff(y)
dftest1=ur.df(dy, type="drift", lags=0, selectlags = "Fixed")
summary(dftest1)

#Engle-Granger metoda
model=lm(y~x)
u=model$residuals
dftest=ur.df(u, type="drift", lags=0, selectlags = "Fixed")
summary(dftest)
nu=length(u)
#ECM
model=lm(dy~dx1+u[2:nu])
beta1=summary(model)$coef[2,1]
beta1

#Johansenova metoda testiranja kointegracije
test=ca.jo(jo_data,type="trace", ecdet="none", K=2, spec="longrun" ) #prvi tip testa,  H_0: (najvise) r veza; H_a: n veza, za r=0,1,...,n.
summary(test)

test2=ca.jo(jo_data,type="eigen", ecdet="none", K=2, spec="longrun" ) #drugi tip testa, H_0: (najvise) r veza; H_a: r+1 veza, za r=0,1,...,n.
summary(test2)

#detaljnije: https://www.quantstart.com/articles/Johansen-Test-for-Cointegrating-Time-Series-Analysis-in-R